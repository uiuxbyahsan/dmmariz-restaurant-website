"use client";

import { useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowRight } from "./decorations/Decorations";

// Each category drives both the price list and the left-hand photo. Edit items
// or swap `image` here as new dishes/photos are added. `highlight` flags a gold
// feature row (e.g. Hadžijski Ćevap).
const categories = [
  {
    name: "Doručak",
    image: "/images/gallery/chicken-mushroom-sauce.jpg",
    items: [
      { name: "Bavarski Doručak", price: "9.00", highlight: false },
      { name: "Mix Doručak", price: "11.00", highlight: false },
    ],
  },
  {
    name: "Glavna Jela",
    image: "/images/gallery/curry-piletina-branded.jpg",
    items: [
      { name: "Curry Piletina", price: "12.00", highlight: false },
      { name: "Wok Piletina", price: "11.00", highlight: false },
      { name: "Sitni Ćevap", price: "10.00", highlight: false },
      { name: "Hadžijski Ćevap", price: "13.00", highlight: true },
      { name: "Toscana Piletina", price: "12.00", highlight: false },
    ],
  },
  {
    name: "Salate",
    image: "/images/gallery/chicken-stirfry-rice.jpg",
    items: [
      { name: "Crispy Chicken Salad", price: "8.00", highlight: false },
    ],
  },
  {
    name: "Sendviči",
    image: "/images/gallery/wok-branded.jpg",
    items: [{ name: "Fokača Sandwich", price: "6.00", highlight: false }],
  },
  {
    name: "Pića",
    image: "/images/gallery/matcha-cocktail.jpg",
    items: [
      { name: "Limunada", price: "4.00", highlight: false },
      { name: "Ledena Kafa", price: "5.00", highlight: false },
    ],
  },
  {
    name: "Kafa",
    image: "/images/gallery/interior-lounge-1.jpg",
    items: [
      { name: "Espresso", price: "2.00", highlight: false },
      { name: "Cappuccino", price: "3.50", highlight: false },
    ],
  },
  {
    name: "Dezerti",
    image: "/images/gallery/curry-chicken-plate.jpg",
    items: [
      { name: "Tiramisu", price: "6.00", highlight: false },
      { name: "Čokoladna Torta", price: "6.50", highlight: false },
    ],
  },
];

const listVariants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.07 } },
};

const rowVariants = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: "easeOut" } },
};

export default function Menu() {
  const [active, setActive] = useState(0);
  const activeCategory = categories[active];

  return (
    <section id="menu" className="dot-texture py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        {/* Heading + category nav */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="font-serif text-4xl md:text-5xl text-maroon-dark">
            Our <span className="italic text-maroon">menu</span>
          </h2>
          <nav className="mt-6 flex flex-wrap items-center gap-x-3 gap-y-2 text-lg md:text-xl text-maroon-dark/70">
            {categories.map((cat, i) => (
              <span key={cat.name} className="flex items-center gap-x-3">
                <button
                  type="button"
                  onClick={() => setActive(i)}
                  aria-pressed={i === active}
                  className={
                    i === active
                      ? "text-maroon-dark font-medium underline decoration-gold decoration-2 underline-offset-4"
                      : "hover:text-maroon transition-colors"
                  }
                >
                  {cat.name}
                </button>
                {i < categories.length - 1 && (
                  <span className="text-maroon-dark/30">/</span>
                )}
              </span>
            ))}
          </nav>
        </motion.div>

        {/* Two-column: photo + price list */}
        <div className="mt-12 grid md:grid-cols-2 gap-10 md:gap-14 items-start">
          {/* Left: tilted photo card with white backing */}
          <div className="relative flex justify-center md:justify-start md:px-6">
            <div className="absolute inset-0 bg-white shadow-xl -rotate-[4deg] rounded-2xl" />
            <motion.div
              initial={{ opacity: 0, rotate: 6, scale: 0.94 }}
              whileInView={{ opacity: 1, rotate: 3, scale: 1 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.7, ease: "easeOut" }}
              className="relative w-full bg-white p-3 shadow-2xl rounded-2xl"
            >
              <div className="relative w-full aspect-[4/5] overflow-hidden rounded-2xl">
                <motion.div
                  key={activeCategory.image}
                  initial={{ opacity: 0, scale: 1.04 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, ease: "easeInOut" }}
                  className="absolute inset-0"
                >
                  <Image
                    src={activeCategory.image}
                    alt={`${activeCategory.name} — DžaMaris`}
                    fill
                    loading="lazy"
                    sizes="(max-width: 768px) 90vw, 520px"
                    className="object-cover"
                  />
                </motion.div>
              </div>
            </motion.div>
          </div>

          {/* Right: price list */}
          <div>
            <motion.ul
              key={activeCategory.name}
              variants={listVariants}
              initial="hidden"
              animate="show"
            >
              {activeCategory.items.map((dish) => (
                <motion.li
                  key={dish.name}
                  variants={rowVariants}
                  className="border-b border-maroon-dark/15"
                >
                  <div className="flex items-baseline justify-between py-4">
                      <span
                        className={`text-lg md:text-xl ${
                          dish.highlight
                            ? "text-gold-dark font-medium"
                            : "text-maroon-dark"
                        }`}
                      >
                        {dish.name}
                      </span>
                      <span
                        className={`text-base md:text-lg whitespace-nowrap pl-4 ${
                          dish.highlight
                            ? "text-gold-dark"
                            : "text-maroon-dark/80"
                        }`}
                      >
                        {dish.price} KM
                      </span>
                    </div>
                  </motion.li>
              ))}
            </motion.ul>

            <a
              href="#gallery"
              className="group mt-7 inline-flex items-center gap-2 text-sm font-semibold uppercase tracking-[0.15em] text-gold-dark hover:text-maroon transition-colors"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-gold-dark transition-colors group-hover:bg-maroon" />
              See All Menu
              <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1.5" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
