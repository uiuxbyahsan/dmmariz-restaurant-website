"use client";

import Image from "next/image";
import { useRef, useState } from "react";
import {
  motion,
  useScroll,
  useTransform,
  useReducedMotion,
} from "framer-motion";

// Wide, full-width spread of 5 tilted photo cards. Order is left → right; the
// center card (index 2) is largest and straightest and sits slightly raised,
// the outer cards are progressively more tilted and pushed lower to form a
// gentle arc. On tablet only the center + two inner cards show; on mobile only
// the center storefront photo remains.
const CENTER = 2;

// Mobile-only compact arc. The center storefront sits highest and largest; the
// four others peek out from behind its edges, partially cropped by the viewport
// (the section is overflow-hidden, so no horizontal scroll). Positions are vw
// based so the spread scales cleanly across 375–414px. Order matches arcPhotos.
const mobilePhotos = [
  {
    src: "/images/gallery/interior-lounge-1.jpg",
    alt: "DžaMaris café interior lounge at Aria Mall",
    rotate: -12,
    z: 10,
    pos: "left-[-6vw] top-[106px]",
    size: "w-[26vw] max-w-[108px]",
    dur: 5,
    amp: 4,
  },
  {
    src: "/images/gallery/wok-branded.jpg",
    alt: "DžaMaris wok chicken stir-fry with rice and salad",
    rotate: -7,
    z: 20,
    pos: "left-[7vw] top-[62px]",
    size: "w-[29vw] max-w-[125px]",
    dur: 4.5,
    amp: 4,
  },
  {
    src: "/images/gallery/aria-mall-exterior.jpg",
    alt: "DžaMaris storefront at Aria Mall, Sarajevo with gold signage under a blue sky",
    rotate: 0,
    z: 30,
    pos: "left-1/2 -translate-x-1/2 top-[14px]",
    size: "w-[50vw] max-w-[200px]",
    dur: 6,
    amp: 6,
  },
  {
    src: "/images/gallery/curry-piletina-branded.jpg",
    alt: "DžaMaris curry piletina plate with fries and coleslaw",
    rotate: 7,
    z: 20,
    pos: "right-[7vw] top-[62px]",
    size: "w-[29vw] max-w-[125px]",
    dur: 5.5,
    amp: 4,
  },
  {
    src: "/images/gallery/matcha-cocktail.jpg",
    alt: "DžaMaris matcha latte and a berry cocktail",
    rotate: 12,
    z: 10,
    pos: "right-[-6vw] top-[106px]",
    size: "w-[26vw] max-w-[108px]",
    dur: 4,
    amp: 4,
  },
];

const arcPhotos = [
  {
    src: "/images/gallery/interior-lounge-1.jpg",
    alt: "DžaMaris café interior lounge at Aria Mall",
    rotate: -11,
    y: 86,
    z: 10,
    box: "w-[164px] h-[212px] xl:w-[178px] xl:h-[232px]",
    show: "hidden lg:block",
    overlap: "lg:-ml-5",
    dur: 5,
    amp: 5,
  },
  {
    src: "/images/gallery/wok-branded.jpg",
    alt: "DžaMaris wok chicken stir-fry with rice and salad",
    rotate: -6,
    y: 38,
    z: 20,
    box: "w-[190px] h-[248px] sm:w-[204px] sm:h-[264px] xl:w-[214px] xl:h-[280px]",
    show: "hidden md:block",
    overlap: "md:-ml-4 lg:-ml-3",
    dur: 4.5,
    amp: 5,
  },
  {
    src: "/images/gallery/aria-mall-exterior.jpg",
    alt: "DžaMaris storefront at Aria Mall, Sarajevo with gold signage under a blue sky",
    rotate: 0,
    y: -24,
    z: 30,
    box: "w-[242px] h-[314px] sm:w-[264px] sm:h-[342px] lg:w-[282px] lg:h-[366px]",
    show: "block",
    overlap: "md:-ml-3 lg:-ml-2",
    priority: true,
    dur: 6,
    amp: 7,
  },
  {
    src: "/images/gallery/curry-piletina-branded.jpg",
    alt: "DžaMaris curry piletina plate with fries and coleslaw",
    rotate: 6,
    y: 38,
    z: 20,
    box: "w-[190px] h-[248px] sm:w-[204px] sm:h-[264px] xl:w-[214px] xl:h-[280px]",
    show: "hidden md:block",
    overlap: "md:-ml-3 lg:-ml-2",
    dur: 5.5,
    amp: 5,
  },
  {
    src: "/images/gallery/matcha-cocktail.jpg",
    alt: "DžaMaris matcha latte and a berry cocktail",
    rotate: 11,
    y: 86,
    z: 10,
    box: "w-[164px] h-[212px] xl:w-[178px] xl:h-[232px]",
    show: "hidden lg:block",
    overlap: "lg:-ml-3",
    dur: 4,
    amp: 5,
  },
];

// Desktop arc card: spring entrance from offscreen → settle → independent idle
// float loop → hover lift, plus a scroll-linked parallax/fade as the hero exits.
function ArcCard({ photo, index, scrollYProgress, reduce }) {
  const [settled, setSettled] = useState(false);
  const [hovered, setHovered] = useState(false);
  const dist = Math.abs(index - CENTER);
  const fromLeft = index < CENTER;
  const isCenter = index === CENTER;

  // Outer cards drift further than the center as the hero scrolls away.
  const parallaxShift = -(50 + dist * 55);
  const parallaxY = useTransform(scrollYProgress, [0, 1], [0, parallaxShift]);
  const parallaxOpacity = useTransform(scrollYProgress, [0, 0.65], [1, 0]);

  const initial = reduce
    ? { opacity: 0 }
    : {
        opacity: 0,
        scale: 0.85,
        rotate: isCenter ? 0 : photo.rotate + (fromLeft ? -8 : 8),
        x: isCenter ? 0 : fromLeft ? -170 : 170,
        y: isCenter ? photo.y - 175 : photo.y + 85,
      };

  const restAnimate = reduce
    ? { opacity: 1 }
    : { opacity: 1, scale: 1, rotate: photo.rotate, x: 0, y: photo.y };

  const floatAnimate = {
    opacity: 1,
    scale: 1,
    rotate: photo.rotate,
    x: 0,
    y: [photo.y, photo.y - photo.amp, photo.y, photo.y + photo.amp, photo.y],
  };

  const animate = reduce ? restAnimate : settled ? floatAnimate : restAnimate;

  const transition =
    settled && !reduce
      ? { y: { duration: photo.dur, repeat: Infinity, ease: "easeInOut" } }
      : reduce
        ? { duration: 0.5, delay: 0.1 + dist * 0.1 }
        : {
            type: "spring",
            stiffness: isCenter ? 80 : 95,
            damping: isCenter ? 11 : 14,
            delay: 0.15 + dist * 0.14,
          };

  return (
    <motion.div
      className={`relative ${photo.show} ${photo.overlap}`}
      style={{
        y: reduce ? undefined : parallaxY,
        opacity: reduce ? undefined : parallaxOpacity,
        zIndex: hovered ? 50 : photo.z,
      }}
    >
      <motion.div
        className="group"
        initial={initial}
        animate={animate}
        transition={transition}
        onAnimationComplete={() => {
          if (!settled) setSettled(true);
        }}
        onHoverStart={() => setHovered(true)}
        onHoverEnd={() => setHovered(false)}
        whileHover={
          reduce
            ? undefined
            : {
                scale: 1.05,
                rotate: photo.rotate * 0.4,
                transition: { duration: 0.3, ease: "easeOut" },
              }
        }
      >
        <div className="rounded-2xl bg-white p-2.5 shadow-xl transition-shadow duration-300 group-hover:shadow-2xl">
          <div className={`relative overflow-hidden rounded-2xl ${photo.box}`}>
            <Image
              src={photo.src}
              alt={photo.alt}
              fill
              priority={photo.priority}
              loading={photo.priority ? undefined : "lazy"}
              sizes="(max-width: 640px) 312px, 332px"
              className="object-cover"
            />
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

// Mobile compact-arc card: same entrance → idle float → hover pattern, but the
// outer wrapper keeps the absolute positioning (incl. -translate-x-1/2) so the
// inner motion transform never clobbers the centering translate.
function MobileCard({ photo, index, reduce }) {
  const [settled, setSettled] = useState(false);
  const dist = Math.abs(index - CENTER);

  const initial = reduce
    ? { opacity: 0 }
    : { opacity: 0, y: 40, rotate: 0, scale: 0.85 };

  const animate = reduce
    ? { opacity: 1 }
    : settled
      ? {
          opacity: 1,
          scale: 1,
          rotate: photo.rotate,
          y: [0, -photo.amp, 0, photo.amp, 0],
        }
      : { opacity: 1, scale: 1, rotate: photo.rotate, y: 0 };

  const transition =
    settled && !reduce
      ? { y: { duration: photo.dur, repeat: Infinity, ease: "easeInOut" } }
      : { duration: 0.6, ease: "easeOut", delay: 0.15 + dist * 0.12 };

  return (
    <div
      className={`absolute ${photo.pos} ${photo.size}`}
      style={{ zIndex: photo.z }}
    >
      <motion.div
        className="group"
        initial={initial}
        animate={animate}
        transition={transition}
        onAnimationComplete={() => {
          if (!settled) setSettled(true);
        }}
        whileHover={
          reduce
            ? undefined
            : {
                scale: 1.06,
                rotate: photo.rotate * 0.4,
                transition: { duration: 0.3, ease: "easeOut" },
              }
        }
      >
        <div className="rounded-2xl bg-white p-2 shadow-xl transition-shadow duration-300 group-hover:shadow-2xl">
          <div className="relative aspect-[3/4] w-full overflow-hidden rounded-2xl">
            <Image
              src={photo.src}
              alt={photo.alt}
              fill
              priority={photo.z === 30}
              loading={photo.z === 30 ? undefined : "lazy"}
              sizes="(max-width: 768px) 60vw, 240px"
              className="object-cover"
            />
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default function Hero() {
  const sectionRef = useRef(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end start"],
  });

  return (
    <section
      ref={sectionRef}
      id="top"
      className="relative overflow-hidden dot-texture pt-24 pb-12 md:pt-28 md:pb-16"
    >
      <div className="relative mx-auto max-w-[1400px] px-4 sm:px-8">
        {/* Mobile compact arc (all 5 photos, layered + peeking) */}
        <div className="relative mx-auto h-[300px] w-full max-w-[420px] md:hidden">
          {mobilePhotos.map((photo, i) => (
            <MobileCard key={photo.src} photo={photo} index={i} reduce={reduce} />
          ))}
        </div>

        {/* Wide fanned photo spread (tablet/desktop) */}
        <div className="hidden items-center justify-center md:flex">
          {arcPhotos.map((photo, i) => (
            <ArcCard
              key={photo.src}
              photo={photo}
              index={i}
              scrollYProgress={scrollYProgress}
              reduce={reduce}
            />
          ))}
        </div>

        {/* Centered text block */}
        <div className="relative z-10 mx-auto mt-10 max-w-2xl text-center md:mt-12">
          <motion.span
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.85 }}
            className="pill bg-gold/25 text-maroon"
          >
            Restoran &amp; Caffe
          </motion.span>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.95 }}
            className="mt-5 font-serif text-3xl leading-[1.08] text-maroon-dark sm:text-4xl lg:text-5xl"
          >
            Real flavors served
            <br />
            with <span className="italic text-maroon">pride</span> in Sarajevo.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1.05 }}
            className="mx-auto mt-6 max-w-xl text-maroon-dark/70 leading-relaxed"
          >
            A family-run Caffe &amp; Restaurant in the heart of Aria Mall,
            Sarajevo, fresh coffee, curry piletina, and sizzling wok plates
            served with a warm Bosnian welcome.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1.2 }}
            className="mt-7 flex justify-center"
          >
            <a href="#location" className="btn btn-primary">
              Explore More
            </a>
          </motion.div>

          {/* Scroll indicator */}
          <motion.a
            href="#menu"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 1.4 }}
            aria-label="Scroll to explore"
            className="mt-8 inline-flex flex-col items-center gap-2 text-maroon-dark/60 transition-colors hover:text-maroon"
          >
            <motion.svg
              viewBox="0 0 24 24"
              className="h-5 w-5"
              fill="none"
              animate={{ y: [0, 7, 0] }}
              transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
            >
              <path
                d="M6 9l6 6 6-6"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </motion.svg>
          </motion.a>
        </div>
      </div>
    </section>
  );
}
